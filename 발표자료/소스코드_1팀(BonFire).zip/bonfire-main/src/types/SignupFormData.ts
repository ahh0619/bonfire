export type SignupFormData = {
  nickname: string;
  email: string;
  password: string;
  passwordConfirm: string;
};
