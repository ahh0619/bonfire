import HeaderPage from './HeaderPage';

const Header = () => {
  return <HeaderPage />;
};

export default Header;
